/**
 * Codeforces Enhancer - Background Service Worker
 * Handles: API request caching, cross-origin requests, periodic cache updates
 */

const API_BASE = 'https://codeforces.com/api';

// ===== CACHE MANAGEMENT =====

/**
 * Global in-memory cache for problem ratings
 * This supplements the content script's localStorage cache
 */
let globalCache = null;
let lastFetchTime = 0;
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Fetch all problemset problems and cache them
 */
async function refreshProblemCache() {
  try {
    console.log('[CFE Background] Refreshing problem cache...');
    const response = await fetch(`${API_BASE}/problemset.problems`);
    const data = await response.json();

    if (data.status === 'OK') {
      globalCache = {};
      for (const problem of data.result.problems) {
        if (problem.rating !== undefined) {
          const key = `${problem.contestId}_${problem.index}`;
          globalCache[key] = {
            rating: problem.rating,
            contestId: problem.contestId,
            index: problem.index,
            name: problem.name
          };
        }
      }
      lastFetchTime = Date.now();
      console.log(`[CFE Background] Cached ${Object.keys(globalCache).length} problems`);
      return true;
    }
  } catch (e) {
    console.error('[CFE Background] Failed to refresh cache:', e);
  }
  return false;
}

/**
 * Get rating from global cache
 */
function getRatingFromGlobalCache(contestId, problemIndex) {
  if (!globalCache) return null;
  const key = `${contestId}_${problemIndex}`;
  const entry = globalCache[key];
  return entry ? entry.rating : null;
}

// ===== MESSAGE HANDLING =====

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  (async () => {
    switch (request.action) {
      case 'getRating': {
        const { contestId, problemIndex } = request;

        // Check global cache first
        let rating = getRatingFromGlobalCache(contestId, problemIndex);

        if (rating === null) {
          // Try to refresh cache
          await refreshProblemCache();
          rating = getRatingFromGlobalCache(contestId, problemIndex);
        }

        sendResponse({ rating });
        break;
      }

      case 'getBatchRatings': {
        const { problems } = request;
        const results = [];

        // Ensure cache is populated
        if (!globalCache || Date.now() - lastFetchTime > CACHE_TTL) {
          await refreshProblemCache();
        }

        for (const { contestId, problemIndex } of problems) {
          const rating = getRatingFromGlobalCache(contestId, problemIndex);
          results.push({ contestId, problemIndex, rating });
        }

        sendResponse({ results });
        break;
      }

      case 'refreshCache': {
        const success = await refreshProblemCache();
        sendResponse({ success, count: globalCache ? Object.keys(globalCache).length : 0 });
        break;
      }

      case 'clearCache': {
        globalCache = null;
        lastFetchTime = 0;
        sendResponse({ success: true });
        break;
      }

      case 'getCacheStats': {
        sendResponse({
          count: globalCache ? Object.keys(globalCache).length : 0,
          lastFetch: lastFetchTime,
          age: Date.now() - lastFetchTime
        });
        break;
      }

      case 'fetchUserRating': {
        try {
          const { handle } = request;
          const response = await fetch(`${API_BASE}/user.info?handles=${handle}`);
          const data = await response.json();

          if (data.status === 'OK' && data.result.length > 0) {
            sendResponse({
              rating: data.result[0].rating,
              maxRating: data.result[0].maxRating,
              rank: data.result[0].rank
            });
          } else {
            sendResponse({ error: 'User not found' });
          }
        } catch (e) {
          sendResponse({ error: e.message });
        }
        break;
      }

      default:
        sendResponse({ error: 'Unknown action' });
    }
  })();

  // Return true to indicate async response
  return true;
});

// ===== ALARMS =====

/**
 * Set up periodic cache refresh
 */
try {
  if (chrome.alarms?.create && chrome.alarms?.onAlarm) {
    chrome.alarms.create('cacheRefresh', {
      periodInMinutes: 60 // Refresh every hour
    });

    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'cacheRefresh') {
        refreshProblemCache();
      }
    });
  }
} catch (e) {
  console.warn('[CFE Background] Alarm setup skipped:', e);
}

// ===== INSTALLATION =====

chrome.runtime.onInstalled.addListener((details) => {
  console.log('[CFE Background] Extension installed/updated:', details.reason);

  // Initial cache population
  refreshProblemCache();

  // Set default settings
  chrome.storage.sync.set({
    userRating: null,
    hideTagsAutomatically: true,
    enableGymIntegration: true,
    enableProblemsetRatings: true
  });
});

// Initial cache load on startup
refreshProblemCache();
