# Codeforces Enhancer - Smart Tags & Ratings

A Chrome extension that enhances the Codeforces problem-solving experience by intelligently hiding problem tags while displaying difficulty ratings, with additional features like blind mode, time-to-solve benchmarks, and gym integration.

## Features

### Core Features (Phase 1)

1. **Selective Tag Hiding with Rating Injection**
   - Automatically detects when Codeforces' native "Show tags for unsolved problems" is disabled
   - Hides problem tags to preserve the learning experience
   - Fetches and displays only the numerical difficulty rating from the Codeforces API
   - Uses localStorage caching for instant loading and API outage protection

2. **"Show All Tags" Fallback Button**
   - Injects a toggle button to reveal hidden tags when stuck
   - Prevents "brick-walling" while maintaining discipline
   - One-click toggle to show/hide tags

3. **Quick-Access Standings Link**
   - Adds a direct hyperlink to contest standings from any problem page
   - Saves navigation time during virtual participation or upsolving

4. **Native Setting Synergy**
   - Leverages Codeforces' built-in tag toggle - zero configuration required
   - Feels like a native upgrade rather than a third-party add-on

### Advanced Features (Phase 2)

5. **Local Data Caching**
   - Problem ratings are cached in localStorage (ratings rarely change)
   - Survives page reloads and protects against API outages
   - Automatic cache eviction when storage is full

6. **Batch Fetching for Problemset**
   - Pre-loads ratings for all visible problems on problemset pages
   - Reduces individual API calls

7. **"Blind Mode" (Click-to-Reveal Rating)**
   - Blurs the difficulty rating until clicked
   - Eliminates difficulty bias during practice
   - Simulates real contest conditions

8. **Gym & Mashup Integration**
   - Parses original problem IDs from mashup URLs
   - Fetches actual ratings and injects them into the Gym interface
   - Supports both Gym problems and Mashup contests

9. **Adaptive Dark Mode Support**
   - Uses CSS variables for automatic theme adaptation
   - Works with Dark Reader, Stylus, and native dark themes
   - Respects `prefers-color-scheme: dark`

10. **"Time-to-Solve" Benchmark**
    - Suggests solve time based on your rating vs problem rating
    - Adds healthy, contest-like pressure to daily practice
    - Difficulty indicators (easy/moderate/hard)

## Installation

### From Source (Developer Mode)

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the extension folder
5. The extension icon should appear in your browser toolbar

### From Chrome Web Store

*Coming soon*

## Configuration

Click the extension icon in your browser toolbar to access settings:

- **Blind Mode**: Toggle to blur ratings until clicked
- **Time-to-Solve**: Toggle suggested solve time display
- **Hide Tags**: Enable/disable automatic tag hiding
- **Problemset Ratings**: Show ratings on problemset pages
- **Gym Integration**: Enable rating display in Gym/Mashup
- **Your Rating**: Set manually or auto-detect from your Codeforces profile

## How It Works

### Tag Hiding
When you visit a Codeforces problem page with tags hidden (via the native setting), the extension:
1. Identifies the problem from the URL
2. Checks the cache for the rating
3. If not cached, fetches from the Codeforces API
4. Displays the rating with appropriate color coding
5. Adds a "Show Tags" button for when you need hints

### Rating Colors
The extension uses Codeforces' official rating colors:
- **Newbie** (< 1200): Gray
- **Pupil** (1200-1399): Green
- **Specialist** (1400-1599): Cyan
- **Expert** (1600-1899): Blue
- **Candidate Master** (1900-2099): Purple
- **Master** (2100-2299): Orange
- **International Master** (2300-2399): Orange
- **Grandmaster** (2400-2599): Red
- **International Grandmaster** (2600-2999): Red
- **Legendary Grandmaster** (>= 3000): Dark Red

## Architecture

```
codeforces-enhancer/
|-- manifest.json          # Extension manifest (v3)
|-- background.js          # Service worker for API calls & caching
|-- content.js             # Main content script for problem pages
|-- problemset.js          # Content script for problemset pages
|-- gym.js                 # Content script for gym/mashup pages
|-- cache.js               # localStorage caching utility
|-- styles.css             # Adaptive styles with dark mode support
|-- popup.html             # Extension popup UI
|-- popup.js               # Popup functionality
|-- popup.css              # Popup styles
|-- icons/                 # Extension icons
    |-- icon16.png
    |-- icon48.png
    |-- icon128.png
```

## API Usage

The extension uses the public Codeforces API:
- `https://codeforces.com/api/problemset.problems` - Fetches all problems with ratings
- `https://codeforces.com/api/user.info` - Fetches user rating (optional)
- `https://codeforces.com/api/contest.standings` - Fetches gym/mashup problem info

All API responses are cached locally to minimize requests.

## Privacy

- No data is sent to any third-party servers
- User ratings are stored locally in browser storage
- API calls are made directly to Codeforces' official API
- No tracking or analytics

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

### Potential Improvements

- [ ] Add problem tags difficulty distribution
- [ ] Add virtual contest timer
- [ ] Add problem recommendation based on weak areas
- [ ] Add solve statistics tracking
- [ ] Support for Codeforces mobile layout
