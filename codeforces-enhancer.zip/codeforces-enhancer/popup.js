/**
 * Codeforces Enhancer - Popup Script
 * Handles: settings toggles, cache management, user rating input
 */

document.addEventListener('DOMContentLoaded', async () => {
  // ===== ELEMENTS =====
  const hideTagsToggle = document.getElementById('hideTags');
  const enableProblemsetToggle = document.getElementById('enableProblemsetRatings');
  const enableGymToggle = document.getElementById('enableGymIntegration');
  const userRatingInput = document.getElementById('userRating');
  const fetchRatingBtn = document.getElementById('fetchRatingBtn');
  const refreshCacheBtn = document.getElementById('refreshCacheBtn');
  const clearCacheBtn = document.getElementById('clearCacheBtn');
  const cacheCountEl = document.getElementById('cacheCount');
  const cacheAgeEl = document.getElementById('cacheAge');
  const statusIndicator = document.getElementById('statusIndicator');

  // ===== STATE =====
  let currentSettings = {};

  // ===== NOTIFICATION =====

  function showNotification(message) {
    const existing = document.querySelector('.popup-notification');
    if (existing) existing.remove();

    const notif = document.createElement('div');
    notif.className = 'popup-notification';
    notif.textContent = message;
    document.body.appendChild(notif);

    requestAnimationFrame(() => {
      notif.classList.add('show');
    });

    setTimeout(() => {
      notif.classList.remove('show');
      setTimeout(() => notif.remove(), 300);
    }, 2000);
  }

  // ===== SETTINGS MANAGEMENT =====

  async function loadSettings() {
    const defaults = {
      hideTagsAutomatically: true,
      enableProblemsetRatings: true,
      enableGymIntegration: true,
      userRating: null
    };

    try {
      const result = await chrome.storage.sync.get(defaults);
      currentSettings = result;

      hideTagsToggle.checked = result.hideTagsAutomatically;
      enableProblemsetToggle.checked = result.enableProblemsetRatings;
      enableGymToggle.checked = result.enableGymIntegration;

      if (result.userRating) {
        userRatingInput.value = result.userRating;
      }
    } catch (e) {
      console.error('[CFE Popup] Could not load settings:', e);
      showNotification('Error loading settings');
    }
  }

  async function saveSetting(key, value) {
    try {
      await chrome.storage.sync.set({ [key]: value });
      currentSettings[key] = value;
      showNotification('Setting saved');
    } catch (e) {
      console.error('[CFE Popup] Could not save setting:', e);
      showNotification('Error saving setting');
    }
  }

  // ===== EVENT LISTENERS =====

  hideTagsToggle.addEventListener('change', (e) => {
    saveSetting('hideTagsAutomatically', e.target.checked);
  });

  enableProblemsetToggle.addEventListener('change', (e) => {
    saveSetting('enableProblemsetRatings', e.target.checked);
  });

  enableGymToggle.addEventListener('change', (e) => {
    saveSetting('enableGymIntegration', e.target.checked);
  });

  userRatingInput.addEventListener('change', async (e) => {
    const raw = e.target.value.trim();
    if (raw === '') {
      await saveSetting('userRating', null);
      showNotification('Baseline set to auto-detect');
      return;
    }

    const value = parseInt(e.target.value);
    if (isNaN(value) || value < 0 || value > 4000) {
      showNotification('Invalid rating (0-4000)');
      return;
    }
    await saveSetting('userRating', value);
  });

  fetchRatingBtn.addEventListener('click', async () => {
    fetchRatingBtn.textContent = '...';
    fetchRatingBtn.disabled = true;

    try {
      // Try to get handle from current Codeforces tab
      const tabs = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });

      const activeTab = tabs[0];
      if (!activeTab?.url?.includes('codeforces.com')) {
        showNotification('Open a Codeforces page first');
        return;
      }

      // Execute script to get handle from page
      const results = await chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        func: () => {
          const handleLink = document.querySelector('.avatar + a[href*="/profile/"], a[href*="/profile/"]');
          return handleLink ? handleLink.textContent.trim() : null;
        }
      });

      const handle = results[0]?.result;
      if (!handle) {
        showNotification('Not logged in to Codeforces');
        return;
      }

      // Fetch rating via background script
      const response = await chrome.runtime.sendMessage({
        action: 'fetchUserRating',
        handle: handle
      });

      if (response.error) {
        showNotification('Could not fetch rating');
      } else {
        userRatingInput.value = response.rating;
        await saveSetting('userRating', response.rating);
        showNotification(`Rating: ${response.rating} (${response.rank})`);
      }
    } catch (e) {
      console.error('[CFE Popup] Fetch rating error:', e);
      showNotification('Error fetching rating');
    } finally {
      fetchRatingBtn.textContent = 'Fetch';
      fetchRatingBtn.disabled = false;
    }
  });

  // ===== CACHE MANAGEMENT =====

  async function updateCacheStats() {
    try {
      // Get stats from background
      const stats = await chrome.runtime.sendMessage({ action: 'getCacheStats' });

      if (stats.count !== undefined) {
        cacheCountEl.textContent = stats.count.toLocaleString();
      }

      if (stats.lastFetch) {
        const age = Date.now() - stats.lastFetch;
        const minutes = Math.floor(age / 60000);
        if (minutes < 1) {
          cacheAgeEl.textContent = 'Just now';
        } else if (minutes < 60) {
          cacheAgeEl.textContent = `${minutes}m ago`;
        } else {
          const hours = Math.floor(minutes / 60);
          cacheAgeEl.textContent = `${hours}h ago`;
        }
      } else {
        cacheAgeEl.textContent = 'Never';
      }
    } catch (e) {
      console.warn('[CFE Popup] Could not get cache stats:', e);
      cacheCountEl.textContent = '-';
      cacheAgeEl.textContent = '-';
    }
  }

  refreshCacheBtn.addEventListener('click', async () => {
    refreshCacheBtn.disabled = true;
    refreshCacheBtn.textContent = 'Refreshing...';

    try {
      const result = await chrome.runtime.sendMessage({ action: 'refreshCache' });
      if (result.success) {
        showNotification(`Cached ${result.count} problems`);
        updateCacheStats();
      } else {
        showNotification('Refresh failed');
      }
    } catch (e) {
      console.error('[CFE Popup] Refresh error:', e);
      showNotification('Error refreshing cache');
    } finally {
      refreshCacheBtn.disabled = false;
      refreshCacheBtn.textContent = 'Refresh';
    }
  });

  clearCacheBtn.addEventListener('click', async () => {
    if (!confirm('Clear all cached ratings?')) return;

    try {
      // Clear via background
      await chrome.runtime.sendMessage({ action: 'clearCache' });

      // Also clear localStorage cache from content scripts
      const tabs = await chrome.tabs.query({ url: '*://codeforces.com/*' });
      for (const tab of tabs) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              localStorage.removeItem('cfe_ratings_cache');
              localStorage.removeItem('cfe_cache_timestamp');
            }
          });
        } catch (e) {
          // Tab might not be accessible
        }
      }

      showNotification('Cache cleared');
      updateCacheStats();
    } catch (e) {
      console.error('[CFE Popup] Clear error:', e);
      showNotification('Error clearing cache');
    }
  });

  // ===== INITIALIZATION =====

  async function init() {
    await loadSettings();
    await updateCacheStats();

    // Update status
    const tabs = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });

    const isCodeforces = tabs[0]?.url?.includes('codeforces.com');
    if (isCodeforces) {
      statusIndicator.className = 'status-indicator active';
      statusIndicator.querySelector('.status-text').textContent = 'Active on Codeforces';
    } else {
      statusIndicator.className = 'status-indicator inactive';
      statusIndicator.querySelector('.status-text').textContent = 'Open Codeforces to use';
    }
  }

  init();
});
