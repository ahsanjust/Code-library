/**
 * Codeforces Enhancer - Cache Utility
 * Handles localStorage-based caching for problem ratings
 * Problem ratings rarely change, so we cache them indefinitely
 */

const Cache = {
  CACHE_KEY: 'cfe_ratings_cache',
  CACHE_TIMESTAMP_KEY: 'cfe_cache_timestamp',
  CACHE_VERSION: '1.0',

  /**
   * Get the entire cache object
   */
  getCache() {
    try {
      const cached = localStorage.getItem(this.CACHE_KEY);
      if (!cached) return {};
      const parsed = JSON.parse(cached);
      // Handle version migration if needed
      if (parsed._version && parsed._version !== this.CACHE_VERSION) {
        this.clearCache();
        return {};
      }
      return parsed.data || parsed;
    } catch (e) {
      console.warn('[CFE] Cache parse error, clearing:', e);
      this.clearCache();
      return {};
    }
  },

  /**
   * Save the entire cache object
   */
  saveCache(cache) {
    try {
      const wrapper = {
        _version: this.CACHE_VERSION,
        _timestamp: Date.now(),
        data: cache
      };
      localStorage.setItem(this.CACHE_KEY, JSON.stringify(wrapper));
      localStorage.setItem(this.CACHE_TIMESTAMP_KEY, Date.now().toString());
    } catch (e) {
      console.warn('[CFE] Cache save error (storage full?):', e);
      // If storage is full, clear old entries
      this.evictOldEntries();
    }
  },

  /**
   * Get cached rating for a specific problem
   * @param {string} contestId - Contest ID
   * @param {string} problemIndex - Problem index (A, B, C, etc.)
   * @returns {number|null} Cached rating or null
   */
  getRating(contestId, problemIndex) {
    const cache = this.getCache();
    const key = `${contestId}_${problemIndex}`;
    const entry = cache[key];
    if (!entry) return null;
    // Check if cache entry is older than 30 days (problem ratings rarely change)
    const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
    if (Date.now() - entry.timestamp > thirtyDaysMs) {
      delete cache[key];
      this.saveCache(cache);
      return null;
    }
    return entry.rating;
  },

  /**
   * Store rating for a specific problem
   * @param {string} contestId - Contest ID
   * @param {string} problemIndex - Problem index
   * @param {number} rating - Problem difficulty rating
   */
  setRating(contestId, problemIndex, rating) {
    const cache = this.getCache();
    const key = `${contestId}_${problemIndex}`;
    cache[key] = {
      rating: rating,
      timestamp: Date.now(),
      contestId: contestId,
      problemIndex: problemIndex
    };
    this.saveCache(cache);
  },

  /**
   * Batch store ratings from problemset API response
   * @param {Array} problems - Array of problem objects from API
   */
  batchSetRatings(problems) {
    const cache = this.getCache();
    let count = 0;
    for (const problem of problems) {
      if (problem.rating !== undefined && problem.rating !== null) {
        const key = `${problem.contestId}_${problem.index}`;
        cache[key] = {
          rating: problem.rating,
          timestamp: Date.now(),
          contestId: problem.contestId,
          problemIndex: problem.index
        };
        count++;
      }
    }
    this.saveCache(cache);
    console.log(`[CFE] Cached ${count} problem ratings`);
  },

  /**
   * Get all cached ratings (useful for debugging)
   */
  getAllCachedRatings() {
    return this.getCache();
  },

  /**
   * Clear entire cache
   */
  clearCache() {
    localStorage.removeItem(this.CACHE_KEY);
    localStorage.removeItem(this.CACHE_TIMESTAMP_KEY);
    console.log('[CFE] Cache cleared');
  },

  /**
   * Get cache statistics
   */
  getStats() {
    const cache = this.getCache();
    const keys = Object.keys(cache).filter(k => !k.startsWith('_'));
    const timestamp = localStorage.getItem(this.CACHE_TIMESTAMP_KEY);
    return {
      count: keys.length,
      lastUpdated: timestamp ? new Date(parseInt(timestamp)).toLocaleString() : 'Never',
      sample: keys.slice(0, 5)
    };
  },

  /**
   * Evict oldest entries when storage is full
   */
  evictOldEntries() {
    const cache = this.getCache();
    const entries = Object.entries(cache)
      .filter(([k]) => !k.startsWith('_'))
      .sort((a, b) => (a[1].timestamp || 0) - (b[1].timestamp || 0));
    // Remove oldest 25%
    const toRemove = Math.ceil(entries.length * 0.25);
    for (let i = 0; i < toRemove; i++) {
      delete cache[entries[i][0]];
    }
    this.saveCache(cache);
    console.log(`[CFE] Evicted ${toRemove} old cache entries`);
  }
};

// Make available globally
window.CFE_Cache = Cache;
